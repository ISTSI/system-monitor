raise RuntimeError("This uploaded fixture must never execute")
